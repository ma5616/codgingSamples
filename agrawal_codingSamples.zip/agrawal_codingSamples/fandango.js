conn = new Mongo("localhost:27017");
db = conn.getDB("Fandango");
coll_1 = db.getCollection("agrawal");
coll_2 = db.getCollection("agrawal2");



doc = {
    _id : ObjectId('A5623CB093FE5942C1F5331D'),
    theaterName : "Regal Eastview Mall",
    theaterAddress : "70 Eastview Mall Drive, NY 14564"
}

coll_1.insertOne(doc)

doc = {
    _id : ObjectId('FFC186A01B3470D8662A1A65'),
    theaterName : "AMC WEBSTER 12",
    theaterAddress : "2190 Empire Blvd., Webster, NY, 14580"
}

coll_1.insertOne(doc)

doc = {
    movieName : "The Whale(2022)",
    rating : "R",
    genre : "Drama",
    duration : "1Hr 57 Min",
    showTimings : "2:50p 5:50p",
    movieTheater : [ObjectId('A5623CB093FE5942C1F5331D')]
}

coll_2.insertOne(doc)

doc = {
    movieName : "M3GAN(2023)",
    rating : "PG-13",
    genre : "Comedy, Horror",
    duration : "1Hr 42 Min",
    showTimings : "4:30p  6:10p  7:20p",
    movieTheater : [ObjectId('A5623CB093FE5942C1F5331D')]
}

coll_2.insertOne(doc)

doc = {
    movieName : "AVATAR: The Way of Water(2022)",
    rating : "PG-13",
    genre : "Fantasy",
    duration : "3 Hr 10 Min",
    showTimings : "3:15p  3:40p  7:30p  8:00p",
    movieTheater : [ObjectId('A5623CB093FE5942C1F5331D')]
}

coll_2.insertOne(doc)

doc = {
    movieName : "MISSING(2023)",
    rating : "PG-13",
    genre : "Drama, Mystry",
    duration : "1 Hr 51 Min",
    showTimings : "1:00p  3:45p  6:45p",
    movieTheater : [ObjectId('FFC186A01B3470D8662A1A65')]
}

coll_2.insertOne(doc)

doc = {
    movieName : "THE FABELMANS",
    rating : "PG-13",
    genre : "Horror",
    duration : "2 Hr 41 Min",
    showTimings : "6:00p",
    movieTheater : [ObjectId('FFC186A01B3470D8662A1A65')]
}

coll_2.insertOne(doc)

doc = {
    movieName : "PUSS IN BOOTS: The Last Wish(2022)",
    rating : "PG",
    genre : "Animated, Kids",
    duration : "1 Hr 42 Min",
    showTimings : "1:30p  4:15p  7:15p",
    movieTheater : [ObjectId('FFC186A01B3470D8662A1A65')]
}

coll_2.insertOne(doc)



cursor = coll_1.aggregate([
    {
      $lookup: {
        from: "agrawal2",
        localField: "_id",
        foreignField: "movieTheater",
        as: "movies"
      }
    }
  ])
  
while (cursor.hasNext()) {
	doc = cursor.next();
	printjson(doc);
}